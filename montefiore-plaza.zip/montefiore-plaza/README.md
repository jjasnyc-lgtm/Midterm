# Montefiore Square — Community Market Redesign Proposal
**Urban Design Studio · Midterm Project · Spring 2025**

A single-page academic website presenting an AI-assisted redesign proposal for Montefiore Square in Harlem, NYC.

---

## 🚀 How to Deploy on GitHub Pages

1. **Upload these files to a new GitHub repo**
   - Go to [github.com](https://github.com) → New repository
   - Name it something like `montefiore-plaza`
   - Upload all files (index.html, css/, js/ folders)

2. **Enable GitHub Pages**
   - In your repo: Settings → Pages
   - Source: `Deploy from a branch`
   - Branch: `main` / root `/`
   - Save → your site will be live at `https://yourusername.github.io/montefiore-plaza`

---

## 📁 File Structure

```
montefiore-plaza/
├── index.html          ← Main website (all sections)
├── css/
│   └── style.css       ← All styles
├── js/
│   └── main.js         ← Nav, animations, counters
├── images/             ← Put your DALL·E images here
│   ├── hero.jpg
│   ├── option-a.jpg
│   ├── option-b.jpg
│   ├── option-c.jpg
│   ├── before.jpg
│   ├── after.jpg
│   └── ...
└── README.md
```

---

## 🖼️ How to Add Your DALL·E Images

Every image slot is marked with a placeholder in `index.html`.
Search for comments like `<!-- REPLACE -->` to find each one.

**To swap in a real image:**
1. Save your DALL·E image to the `images/` folder
2. In `index.html`, replace the placeholder `<div>` with:
   ```html
   <img src="images/your-image.jpg" alt="Description" style="width:100%;height:100%;object-fit:cover;">
   ```

---

## ✏️ How to Customize Content

- **Your name / course info** → search for "Spring 2025" and update
- **Project track** → update the About section text to match your actual track
- **Stats** → update the `data-count` values in the hero stats
- **Site facts** → update the fact rows in the Site section
- **Design options** → rename Option A/B/C and update descriptions to match your actual iterations
- **Prompt log** → update the AI prompts to your real prompt history
- **Reflection** → write your own human reflection in the Reflection section

---

## 🎨 Color Customization (css/style.css)

Change any color by editing the CSS variables at the top of `style.css`:

```css
:root {
  --rust: #c4502a;      /* Main accent color */
  --gold: #c9963a;      /* Secondary accent */
  --sage: #5a6e52;      /* Green accent */
  --ink: #0d0d0d;       /* Dark background */
  --cream: #f5f0e8;     /* Light background */
}
```

---

## 📋 Required Website Sections Checklist

- [x] Home (hero)
- [x] About the Project
- [x] The Problem
- [x] Site / Context
- [x] Design Options
- [x] Final Proposal
- [x] Reflection / Conclusion

All 7 required sections are included and clearly labeled.
